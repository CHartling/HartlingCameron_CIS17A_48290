/* 
 * File:   Employee.cpp
 * Author: Cameron Hartling
 * Created on December 13th, 2022, 6:14 PM
 * Purpose:  Problem 5: Calculates an employees Pay
 */

#include "Employee.h"
#include <iostream>  //I/O Library
using namespace std;

Employee::Employee(char n[20], char j[20], float hr){
    for(int i = 0; i < 20; i++){
        MyName[i] = n[i];
    }
    for(int i = 0; i < 20; i++){
        JobTitle[i] = j[i];
    }
    HourlyRate = setHourlyRate(hr);
    GrossPay = 0.0;
    NetPay = 0.0;
}

float Employee::CalculatePay(float hr, int h){
    return  getNetPay(getGrossPay(setHourlyRate(hr),setHoursWorked(h)));
}

float Employee::getGrossPay(float hr, int h){
    if (h > 50){
        GrossPay += 2 * h * hr;
        h = 50;
    }
    else if(h > 40){
        GrossPay += 1.5 * h * hr;
        h = 40;
    }
    else{
        GrossPay += h * hr;
    }
    
    return GrossPay;
}

float Employee::getNetPay(float gp){
    NetPay = gp - double(Tax(gp));
    return NetPay;
}

int Employee::setHoursWorked(int h){
    if(h <= 0 || h >= 84){
        string exceptionString = "Unacceptable Hours Worked\n";
        throw exceptionString;
    }
    
    HoursWorked = h;
    return HoursWorked;
}

float Employee::setHourlyRate(float hr){
    if (hr <= 0 || hr >= 200){
        string exceptionString = "Unacceptable Hourly Rate\n";
        throw exceptionString;
    }
    
    HourlyRate = hr;
    return HourlyRate;
}

double Employee::Tax(float p){
    double tax = 0.0;
    double gp = double(p);
    
    if (gp > 1000){
        tax = tax + ((gp - 1000) * 0.3);
        gp = 1000;
    }
    else if(gp > 500){
        tax = tax + ((gp - 500) * 0.2);
        gp = 500;
    }
    else{
        tax = tax + (gp * 0.1);
    }
    
    return tax;
}

void Employee::toString(){
    //Print all Properties
    cout << "Name = ";
    for(int i = 0; i < 4; i++){
        cout << MyName[i];
    }
    cout << "  Job Title = ";
    for(int i = 0; i < 4; i++){
        cout << JobTitle[i];
    }
    
    cout << endl << "Hourly Rate = " << HourlyRate << " Hours Worked = " << HoursWorked << " Gross Pay = " << GrossPay << " Net Pay = " << NetPay << endl;
    
}