/* 
 * File:   Prob2Sort.cpp
 * Author: Cameron Hartling
 * Created on December 13th, 2022, 6:14 PM
 * Purpose:  Problem 2: 
 */

//System Libraries
#include <iostream>  //I/O Library
#include <fstream>
using namespace std;

//This class sorts arrays either ascending or descending
template<class T>
class Prob2Sort{
    private:
        int *index; //Index that is utilized in the sort
    public:
        Prob2Sort(){index = NULL;}; //Constructor
        ~Prob2Sort(){delete []index;}; //Destructor
        T * sortArray(const T*,int,bool); //Sorts a single column array
        T * sortArray(const T*,int,int,int,bool);//Sorts a 2 dimensional array represented as a 1 dim array
};



template<class T>
T* Prob2Sort::sortArray(const T* arr,int x,bool a){
    index = new int[x];
    
    
    return arr;
}

template<class T>
T* Prob2Sort::sortArray(const T* arr,int x,int y,int c,bool a){
    
    
    
    return arr;
}