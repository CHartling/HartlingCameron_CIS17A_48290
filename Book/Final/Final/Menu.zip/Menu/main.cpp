/* 
 * File:   main.cpp
 * Author: Cameron Hartling
 * Created on December 13th, 2022, 6:14 PM
 * Purpose:  Final Exam Menu File
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <ctime>
#include <cstring>
using namespace std;

//User Libraries
#include "Prob1Random.cpp"
#include "Prob2Sort.cpp"
#include "Problem3.txt"
#include "SavingsAccount.cpp"
#include "Employee.cpp"

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes
void menu();
void prob1();
void prob2();
void prob3();
void prob4();
void prob5();
void prob6();

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    char choice;


    //Loop and Display menu
    do {
        menu();
        cin >> choice;

        //Process/Map inputs to outputs
        switch (choice) {
            case '1': {prob1(); break; }
            case '2': {prob2(); break; }
            case '3': {prob3(); break; }
            case '4': {prob4(); break; }
            case '5': {prob5(); break; }
            case '6': {prob6(); break; }
            default: cout << "Exiting Menu" << endl;
        }
    } while (choice >= '1' && choice <= '7');

    //Exit stage right!
    return 0;
}//end main


//Menu
//Input:  -> None
//Output: -> No Return, Print menu
void menu() {
    //Display menu
    cout << endl << "Choose from the following Menu" << endl;
    cout << "Type 1 for Problem 1" << endl;
    cout << "Type 2 for Problem 2" << endl;
    cout << "Type 3 for Problem 3" << endl;
    cout << "Type 4 for Problem 4" << endl;
    cout << "Type 5 for Problem 5" << endl;
    cout << "Type 6 for Problem 6" << endl << endl;
}//end menu



//Problem 1
//Input:  -> None, data on customer bank account
//Output: -> No Return, Print Customer Struct data
void prob1() {
    cout << endl << "Problem 1" << endl << endl;
    //Initialize variables
    //Set random seed
    srand(time(NULL));

    //Initialize
    char n = 5;
    char rndseq[] = { 19,34,57,79,126 };
    int ntimes = 100000;
    Prob1Random a(n, rndseq);

    for (int i = 1; i <= ntimes; i++) {
        a.randFromSet();
    }

    int* x = a.getFreq();
    char* y = a.getSet();

    for (int i = 0; i < n; i++) {
        cout << int(y[i]) << " occurred " << x[i] << " times" << endl;
    }

    cout << "The total number of random numbers is " << a.getNumRand() << endl;
}//end prob1

//Problem 2
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
void prob2() {
    cout << endl << "Problem 2" << endl << endl;
    // Initialize variables
    cout << "The start of Problem 2, the sorting problem" << endl;
    Prob2Sort<char> rc;
    bool ascending = true;
    ifstream infile;
    infile.open("Problem2.txt",ios::in);
    
    char *ch2 = new char[10*16];
    char *ch2p = ch2;
    
    while( infile.get(*ch2) ){
        cout << *ch2; ch2++;
    }
    
    infile.close();
    
    cout << endl;
    
    cout << "Sorting on which column"<<endl;
    int column;
    cin >> column;
    char *zc = rc.sortArray(ch2p,10,16,column,ascending);
    
    for(int i = 0; i < 10; i++){
        for(int j = 0; j < 16; j++){
            cout << zc[i*16+j];
        }
    }
    
    delete []zc;
    cout << endl;
}//end prob2



//Problem 3
//Class
template<class T>
class Prob3Table{
    protected:
        int rows; //Number of rows in the table
        int cols; //Number of cols in the table
        T *rowSum; //RowSum array
        T *colSum; //ColSum array
        T *table; //Table array
        T grandTotal; //Grand total
        void calcTable(); //Calculate all the sums
    public:
        Prob3Table(char *tab,int r,int c); //Constructor then Destructor
        ~Prob3Table(){delete [] table; delete [] rowSum; delete [] colSum;};
        const T *getTable(){return table;};
        const T *getRowSum(){return rowSum;};
        const T *getColSum(){return colSum;};
        T getGrandTotal(){return grandTotal;};
};

template<class T>
class Prob3TableInherited:public Prob3Table<T>{
    protected:
        T *augTable; //Augmented Table with sums
    public:
        Prob3TableInherited(char *tab, int r, int c); //Constructor
        ~Prob3TableInherited(){delete [] augTable;}; //Destructor
        const T *getAugTable(){return augTable;};
};

template<class T>
Prob3TableInherited::Prob3TableInherited(char *tab, int r, int c){
    rows = r;
    cols = c;
    augTable = new T[rows+1][cols+1];
    augTable = tab;
    table = new T[rows][cols];
    table = tab;
    rowSum = new T[rows];
    colSum = new T[cols];
    grandTotal = 0;
}


void Prob3TableInherited::calcTable(){
    unsigned int i;
    unsigned int j;
    
    //Calculate row sums
    for (i = 0; i < rows; i++){
        rowSum[i] = 0;
        for (j = 0; j < cols; i++){
            rowSum[j] = table[j][i];
        }
    }
    
    //Calculate column sums
    for (i = 0; i < rows; i++){
        colSum[i] = 0;
        for (j = 0; j < cols; i++){
            colSum[j] = table[i][j];   
        }
    }
    
    //Calculate total sum
    for (j = 0; j < cols; i++){
            grandTotal += colSum[j];   
        }
    
}
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
void prob3() {
    cout << endl << "Problem 3" << endl;
    int rows = 5;
    int cols = 6;
    
    Prob3TableInherited<int> tab("Problem3.txt",rows,cols);
    const int *naugT = tab.getTable();
    for(int i = 0; i < rows; i++){
        for(int j = 0; j < cols; j++){
            cout << naugT[i*cols+j] << " ";
        }
        cout << endl;
    }
    cout << endl;
    
    const int *augT = tab.getAugTable();
    for(int i = 0; i <= rows; i++){
        for(int j = 0; j <= cols; j++){
            cout << augT[i*(cols+1)+j] << " ";
        }
        cout << endl;
    }
}//end pro3



//Problem 4
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
void prob4() {
    cout << endl << "Problem 4" << endl << endl;
    //Set random seed
    srand(time(NULL));
    
    SavingsAccount mine(-300);
    for(int i=1;i<=10;i++){
        mine.Transaction((float)(rand()%500)*(rand()%3-1));
    }
     
    mine.toString();
    cout << "Balance after 7 years given 10% interest = " << mine.Total((float)(0.10),7) << endl;
    cout << "Balance after 7 years given 10% interest = " << mine.TotalRecursive((float)(0.10),7) << " Recursive Calculation " << endl;
}//end prob4



//Problem 5
//Input:  -> None
//Output: -> No Return, Output answers to questions
void prob5() {
    cout << endl << "Problem 5" << endl << endl;
    //Example Input
    char name1[20] = "Mark";
    char name2[20] = "Mary";
    char job1[20] = "Boss";
    char job2[20] = "VP";
    
    try{
        Employee Mark(name1,job1,215.50);
    
        Mark.setHoursWorked(-3);
    
        Mark.toString();
    
        Mark.CalculatePay(Mark.setHourlyRate(20.0),Mark.setHoursWorked(25));
        Mark.toString();
    
        Mark.CalculatePay(Mark.setHourlyRate(40.0),Mark.setHoursWorked(25));
        Mark.toString();
    
        Mark.CalculatePay(Mark.setHourlyRate(60.0),Mark.setHoursWorked(25));
        Mark.toString();
    }
    
    catch(string exceptionString){
        cout << exceptionString;
    }
    try{
        Employee Mary(name2,job2,50.0);
        Mary.toString();
        Mary.CalculatePay(Mary.setHourlyRate(50.0),Mary.setHoursWorked(40));
        Mary.toString();
        Mary.CalculatePay(Mary.setHourlyRate(50.0),Mary.setHoursWorked(50));
        Mary.toString();
        Mary.CalculatePay(Mary.setHourlyRate(50.0),Mary.setHoursWorked(60));
        Mary.toString();
    }
    catch(string exceptionString){
        cout << exceptionString;
    }
}//end prob5



//Problem 6
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
void prob6() {
    cout << endl << "Problem 6" << endl << endl;
    cout << "See pdf" << endl;
}//end prob6