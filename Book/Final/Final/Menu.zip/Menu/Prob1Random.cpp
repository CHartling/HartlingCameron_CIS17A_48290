/*
 * File:   main.cpp
 * Author: Cameron Hartling
 * Created on December 13th, 2022, 6:14 PM
 * Purpose:  Problem 1: Random class
 */

#include "Prob1Random.h"
#include <cstdlib>
using namespace std;

Prob1Random::Prob1Random(const char n, const char* rndseq) {
    unsigned int i;
    numRand = 0;
    nset = n;
    set = new char(nset);
    for (i = 0; i < int(nset); i++) {
        set[i] = rndseq[i];
    }
    
    freq = new int(nset);
    for (i = 0; i < int(nset); i++) {
        freq[i] = 0;
    }
}

Prob1Random::~Prob1Random(){
    delete[] set;
    delete[] freq;
}

char Prob1Random::randFromSet() {
    //Get random position of the set
    int rNum = rand() % nset;

    freq[rNum] += 1;

    numRand++;

    return set[rNum];
}

int* Prob1Random::getFreq() const {
    return freq;
}

char* Prob1Random::getSet() const {
    return set;
}

int Prob1Random::getNumRand() const {
    return numRand;
}