/* 
 * File:   main.cpp
 * Author: Cameron Hartling
 * Created on December 13th, 2022, 6:14 PM
 * Purpose:  Problem 3: 
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries
#include "Problem3.txt"

//Class
template<class T>
class Prob3Table{
    protected:
        int rows; //Number of rows in the table
        int cols; //Number of cols in the table
        T *rowSum; //RowSum array
        T *colSum; //ColSum array
        T *table; //Table array
        T grandTotal; //Grand total
        void calcTable(); //Calculate all the sums
    public:
        Prob3Table(char *tab,int r,int c); //Constructor then Destructor
        ~Prob3Table(){delete [] table; delete [] rowSum; delete [] colSum;};
        const T *getTable(){return table;};
        const T *getRowSum(){return rowSum;};
        const T *getColSum(){return colSum;};
        T getGrandTotal(){return grandTotal;};
};

template<class T>
class Prob3TableInherited:public Prob3Table<T>{
    protected:
        T *augTable; //Augmented Table with sums
    public:
        Prob3TableInherited(char *tab, int r, int c); //Constructor
        ~Prob3TableInherited(){delete [] augTable;}; //Destructor
        const T *getAugTable(){return augTable;};
};

template<class T>
Prob3TableInherited::Prob3TableInherited(char *tab, int r, int c){
    rows = r;
    cols = c;
    augTable = new T[rows+1][cols+1];
    augTable = tab;
    table = new T[rows][cols];
    table = tab;
    rowSum = new T[rows];
    colSum = new T[cols];
    grandTotal = 0;
}


void Prob3TableInherited::calcTable(){
    unsigned int i;
    unsigned int j;
    
    //Calculate row sums
    for (i = 0; i < rows; i++){
        rowSum[i] = 0;
        for (j = 0; j < cols; i++){
            rowSum[j] = table[j][i];
        }
    }
    
    //Calculate column sums
    for (i = 0; i < rows; i++){
        colSum[i] = 0;
        for (j = 0; j < cols; i++){
            colSum[j] = table[i][j];   
        }
    }
    
    //Calculate total sum
    for (j = 0; j < cols; i++){
            grandTotal += colSum[j];   
        }
    
}


//Execution of Code Begins Here
int main(int argc, char** argv) {
    cout << "Entering problem number 3" << endl;
    int rows = 5;
    int cols = 6;
    
    Prob3TableInherited<int> tab("Problem3.txt",rows,cols);
    const int *naugT = tab.getTable();
    for(int i = 0; i < rows; i++){
        for(int j = 0; j < cols; j++){
            cout << naugT[i*cols+j] << " ";
        }
        cout << endl;
    }
    cout << endl;
    
    const int *augT = tab.getAugTable();
    for(int i = 0; i <= rows; i++){
        for(int j = 0; j <= cols; j++){
            cout << augT[i*(cols+1)+j] << " ";
        }
        cout << endl;
    }

    return 0;
}