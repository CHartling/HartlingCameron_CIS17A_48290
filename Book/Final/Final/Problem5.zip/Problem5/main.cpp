/* 
 * File:   main.cpp
 * Author: Cameron Hartling
 * Created on December 13th, 2022, 6:14 PM
 * Purpose:  Problem 5: Calculates an employees Pay
 */

//System Libraries

#include <iostream>  //I/O Library
using namespace std;

//User Libraries
#include "Employee.cpp"


//Execution of Code Begins Here
int main(int argc, char** argv) {
    //Example Input
    char name1[20] = "Mark";
    char name2[20] = "Mary";
    char job1[20] = "Boss";
    char job2[20] = "VP";
    
    try{
        Employee Mark(name1,job1,215.50);
    
        Mark.setHoursWorked(-3);
    
        Mark.toString();
    
        Mark.CalculatePay(Mark.setHourlyRate(20.0),Mark.setHoursWorked(25));
        Mark.toString();
    
        Mark.CalculatePay(Mark.setHourlyRate(40.0),Mark.setHoursWorked(25));
        Mark.toString();
    
        Mark.CalculatePay(Mark.setHourlyRate(60.0),Mark.setHoursWorked(25));
        Mark.toString();
    }
    
    catch(string exceptionString){
        cout << exceptionString;
    }
    try{
        Employee Mary(name2,job2,50.0);
        Mary.toString();
        Mary.CalculatePay(Mary.setHourlyRate(50.0),Mary.setHoursWorked(40));
        Mary.toString();
        Mary.CalculatePay(Mary.setHourlyRate(50.0),Mary.setHoursWorked(50));
        Mary.toString();
        Mary.CalculatePay(Mary.setHourlyRate(50.0),Mary.setHoursWorked(60));
        Mary.toString();
    }
    catch(string exceptionString){
        cout << exceptionString;
    }
    
    return 0;
}

//Function Implementations