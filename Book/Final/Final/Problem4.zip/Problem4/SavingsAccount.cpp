/* 
 * File:   SavingsAccount.cpp
 * Author: Cameron Hartling
 * Created on December 13th, 2022, 6:14 PM
 * Purpose:  Problem 4: Savings Account Class
 */

#include "SavingsAccount.h"
#include <string>
#include <iostream>
using namespace std;

SavingsAccount::SavingsAccount(float b){
    if (b > 0){
        Balance = b;
    }
    else
        Balance = 0;
    FreqWithDraw = 0;
    FreqDeposit = 0;
}

void SavingsAccount::Transaction(float n){
    if (n > 0){
        Deposit(n);
    }
    else
        Withdraw(n);
}

float SavingsAccount::Withdraw(float w){
    if((Balance + w) < 0){
        string exceptionString = "Withdraw not allowed\n";
        throw exceptionString;
    }    
    FreqWithDraw++;
    return 0;
}

float SavingsAccount::Deposit(float d){
    Balance += d;
    FreqDeposit++;
    return 0;
}

void SavingsAccount::toString(){
    cout << "Balance   = " << Balance << endl;
    cout << "Withdraws = " << FreqWithDraw << endl;
    cout << "Deposits  = " << FreqDeposit << endl;
}

float SavingsAccount::Total(float savint,int time){
    float total = Balance;
    for (int i = 0; i < time; i++){
        total = total * (1+savint);
    }
    
    return total;
}

float SavingsAccount::TotalRecursive(float savint,int time){
    float total = Balance;
    if (time > 0){
        return TotalRecursive(savint,time - 1) * (1+savint);
    }
    else
        return total;
}