/* 
 * File:   main.cpp
 * Author: Cameron Hartling
 * Created on December 13th, 2022, 6:14 PM
 * Purpose:  Problem 4: Savings Account Class
 */

//System Libraries
#include <iostream>  //I/O Library
#include <cstdlib>
#include <ctime>
using namespace std;

//User Libraries
#include "SavingsAccount.cpp"


//Execution of Code Begins Here
int main(int argc, char** argv) {
    //Set random seed
    srand(time(NULL));
    
    SavingsAccount mine(-300);
    for(int i=1;i<=10;i++){
        mine.Transaction((float)(rand()%500)*(rand()%3-1));
    }
     
    mine.toString();
    cout << "Balance after 7 years given 10% interest = " << mine.Total((float)(0.10),7) << endl;
    cout << "Balance after 7 years given 10% interest = " << mine.TotalRecursive((float)(0.10),7) << " Recursive Calculation " << endl;

    
    return 0;
}